#ifndef _GLOBALS_H
#define _GLOBALS_H

#define OK 0
#define ERR -2

#define T 1
#define F 0

#endif